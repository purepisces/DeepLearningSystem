# This is python/needle/nn/nn_basic.py
"""The module.
"""
from typing import List, Callable, Any
from needle.autograd import Tensor
from needle import ops
import needle.init as init
import numpy as np


class Parameter(Tensor):
    """A special kind of tensor that represents parameters."""


def _unpack_params(value: object) -> List[Tensor]:
    if isinstance(value, Parameter):
        return [value]
    elif isinstance(value, Module):
        return value.parameters()
    elif isinstance(value, dict):
        params = []
        for k, v in value.items():
            params += _unpack_params(v)
        return params
    elif isinstance(value, (list, tuple)):
        params = []
        for v in value:
            params += _unpack_params(v)
        return params
    else:
        return []


def _child_modules(value: object) -> List["Module"]:
    if isinstance(value, Module):
        modules = [value]
        modules.extend(_child_modules(value.__dict__))
        return modules
    if isinstance(value, dict):
        modules = []
        for k, v in value.items():
            modules += _child_modules(v)
        return modules
    elif isinstance(value, (list, tuple)):
        modules = []
        for v in value:
            modules += _child_modules(v)
        return modules
    else:
        return []


class Module:
    def __init__(self):
        self.training = True

    def parameters(self) -> List[Tensor]:
        """Return the list of parameters in the module."""
        return _unpack_params(self.__dict__)

    def _children(self) -> List["Module"]:
        return _child_modules(self.__dict__)

    def eval(self):
        self.training = False
        for m in self._children():
            m.training = False

    def train(self):
        self.training = True
        for m in self._children():
            m.training = True

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)


class Identity(Module):
    def forward(self, x):
        return x


class Linear(Module):
    def __init__(
        self, in_features, out_features, bias=True, device=None, dtype="float32"
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        ### BEGIN YOUR SOLUTION
        self.weight = Parameter(init.kaiming_uniform(in_features, out_features, nonlinearity="relu", dtype=dtype))
        if bias:
            self.bias = Parameter(init.kaiming_uniform(out_features, 1, dtype=dtype).transpose())
        else:
            self.bias = None
        ### END YOUR SOLUTION

    def forward(self, X: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        output = ops.matmul(X, self.weight)
        if self.bias:
            broadcast_shape = list(output.shape[:-1]) + [self.out_features]
            broadcasted_bias = ops.broadcast_to(self.bias, tuple(broadcast_shape))
            output = ops.add(output, broadcasted_bias)
        return output
        ### END YOUR SOLUTION


class Flatten(Module):
    def forward(self, X):
        ### BEGIN YOUR SOLUTION
        batch_size = X.shape[0]
        return X.reshape((batch_size, -1))
        ### END YOUR SOLUTION


class ReLU(Module):
    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        return ops.relu(x)
        ### END YOUR SOLUTION

class Sequential(Module):
    def __init__(self, *modules):
        super().__init__()
        self.modules = modules

    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        for module in self.modules:
            x = module(x)
        return x
        ### END YOUR SOLUTION


class SoftmaxLoss(Module):
    def forward(self, logits: Tensor, y: Tensor):
        ### BEGIN YOUR SOLUTION
        y_one_hot = init.one_hot(logits.shape[1], y)
        log_sum_exp_Z = ops.logsumexp(logits, axes=1)
        total_log_sum_exp_Z = ops.summation(log_sum_exp_Z)
        product_Z_y_one_hot = logits * y_one_hot
        sum_product_Z_y_one_hot = ops.summation(product_Z_y_one_hot)
        loss = (total_log_sum_exp_Z - sum_product_Z_y_one_hot) / logits.shape[0]
        return loss
        ### END YOUR SOLUTION


class BatchNorm1d(Module):
    def __init__(self, dim, eps=1e-5, momentum=0.1, device=None, dtype="float32"):
        super().__init__()
        self.dim = dim
        self.eps = eps
        self.momentum = momentum
        ### BEGIN YOUR SOLUTION
        self.weight = Parameter(init.ones(dim, dtype=dtype, requires_grad=True))
        self.bias = Parameter(init.zeros(dim, dtype=dtype, requires_grad=True))
        self.running_mean = init.zeros(dim, dtype=dtype, requires_grad=False)
        self.running_var = init.ones(dim, dtype=dtype, requires_grad=False)
        ### END YOUR SOLUTION

    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        if self.training:
            batch_mean = ops.summation(x, axes=(0,)) / x.shape[0]
            batch_mean_reshaped = batch_mean.reshape((1, self.dim))  
            batch_var = ops.summation(ops.power_scalar((x - batch_mean_reshaped.broadcast_to(x.shape)), 2), axes=(0,)) / x.shape[0]
            batch_var_reshaped = batch_var.reshape((1, self.dim))
            self.running_mean = (1 - self.momentum) * self.running_mean + self.momentum * batch_mean
            self.running_var = (1 - self.momentum) * self.running_var + self.momentum * batch_var
            x_normalized = (x - batch_mean_reshaped.broadcast_to(x.shape)) / ops.power_scalar((batch_var_reshaped.broadcast_to(x.shape) + self.eps), 0.5)
            return self.weight.broadcast_to(x.shape) * x_normalized + self.bias.broadcast_to(x.shape)
        else:
            running_mean_reshaped = self.running_mean.reshape((1, self.dim))
            running_var_reshaped = self.running_var.reshape((1, self.dim))
            x_normalized = (x - running_mean_reshaped.broadcast_to(x.shape)) / ops.power_scalar((running_var_reshaped.broadcast_to(x.shape) + self.eps), 0.5)
            return self.weight.broadcast_to(x.shape) * x_normalized + self.bias.broadcast_to(x.shape)
        ### END YOUR SOLUTION


class LayerNorm1d(Module):
    def __init__(self, dim, eps=1e-5, device=None, dtype="float32"):
        super().__init__()
        self.dim = dim
        self.eps = eps
        ### BEGIN YOUR SOLUTION
        self.weight = Parameter(init.ones(dim, dtype=dtype, requires_grad=True))
        self.bias = Parameter(init.zeros(dim, dtype=dtype, requires_grad=True))
        ### END YOUR SOLUTION

    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        # Compute mean
        mean_per_batch = ops.summation(x, axes=(1,)) / self.dim
        mean = ops.reshape(mean_per_batch, (x.shape[0], 1))
        mean_broadcasted = ops.broadcast_to(mean, x.shape)
        # Compute variance
        var_per_batch = ops.summation(ops.power_scalar(x - mean_broadcasted, 2), axes=(1,)) / self.dim
        var = ops.reshape(var_per_batch, (x.shape[0], 1))
        var_broadcasted = ops.broadcast_to(var, x.shape)
        # Normalization and output calculation
        deno = ops.power_scalar(var_broadcasted + self.eps, 0.5)
        out = self.weight.broadcast_to(x.shape) * (x - mean_broadcasted) / deno + self.bias.broadcast_to(x.shape)
        return out

        ### END YOUR SOLUTION


class Dropout(Module):
    def __init__(self, p=0.5):
        super().__init__()
        self.p = p

    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        if self.training:
            keep_mask = init.randb(*x.shape, p=1-self.p, dtype=x.dtype) 
            return x * keep_mask / (1 - self.p)
        else:
            return x
        ### END YOUR SOLUTION


class Residual(Module):
    def __init__(self, fn: Module):
        super().__init__()
        self.fn = fn

    def forward(self, x: Tensor) -> Tensor:
        ### BEGIN YOUR SOLUTION
        return x + self.fn(x)
        ### END YOUR SOLUTION
