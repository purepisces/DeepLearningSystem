#python/needle/ops/ops_logarithmic.py
from typing import Optional
from ..autograd import NDArray
from ..autograd import Op, Tensor, Value, TensorOp
from ..autograd import TensorTuple, TensorTupleOp

from .ops_mathematic import *

import numpy as array_api

class LogSoftmax(TensorOp):
    def compute(self, Z):
        ### BEGIN YOUR SOLUTION
        raise NotImplementedError()
        ### END YOUR SOLUTION

    def gradient(self, out_grad, node):
        ### BEGIN YOUR SOLUTION
        raise NotImplementedError()
        ### END YOUR SOLUTION


def logsoftmax(a):
    return LogSoftmax()(a)
    
class LogSumExp(TensorOp):
    def __init__(self, axes: Optional[tuple] = None):
        self.axes = axes

    def compute(self, Z):
        ### BEGIN YOUR SOLUTION
        z_max_origindim = array_api.max(Z, self.axes, keepdims=True)
        sum_exp = array_api.sum(array_api.exp(Z - z_max_origindim), self.axes)
        result = array_api.log(sum_exp) + array_api.squeeze(z_max_origindim, self.axes)
        return result
        ### END YOUR SOLUTION

    def gradient(self, out_grad, node): 
        
        ### BEGIN YOUR SOLUTION
        z = node.inputs[0].cached_data
        z_max_origindim = array_api.max(z, self.axes, keepdims=True)
        sum_exp = array_api.sum(array_api.exp(z - z_max_origindim), self.axes)
        grad_sum_exp_z = out_grad.cached_data / sum_exp
        broadcast_shape = [1] * len(z.shape) if self.axes is None else list(z.shape)
        if self.axes is not None:
            axes_iterable = (self.axes,) if isinstance(self.axes, int) else self.axes
            for axis in axes_iterable:
                broadcast_shape[axis] = 1
        grad = array_api.exp(z - z_max_origindim) * array_api.reshape(grad_sum_exp_z, tuple(broadcast_shape))
        return Tensor(grad)
        ### END YOUR SOLUTION

def logsumexp(a, axes=None):
    return LogSumExp(axes=axes)(a)